package com.shutl.controller;

import com.shutl.model.Quote;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

@RestController
public class QuoteController {

	private static String[] vehicles = {"bicycle","motorbike","parcel_car","small_van","large_van"};
	private static double[] modifiers = {0.1, 0.15, 0.2, 0.3, 0.4};
	private static Long[] limits = {new Long(500), new Long(750), new Long(1000), new Long(1500), Long.MAX_VALUE};
	
	/**
	 * I have made a slight alteration to the calculation of the pricing between two post codes. The application
	 * now works out the pricing by removing all letters within a post code, leaving only numbers and then multiples
	 * the two numbers from the separate post codes together to obtain the price. With this implementation I assume
	 * that a post code will always contain at least one number.
	 */
    @RequestMapping(value = "/quote", method = POST)
    public @ResponseBody Quote quote(@RequestBody Quote quote) {
        
        String dPC = quote.getDeliveryPostcode();
        String pPC = quote.getPickupPostcode();
         
        String s1 = dPC.replaceAll("[*a-zA-Z]", "");
        String s2 = pPC.replaceAll("[*a-zA-Z]", "");
        
        Long price  = new Long(Long.parseLong(s1) * Long.parseLong(s2));
        
        try{
        	String vehicle = quote.getVehicle();
        	vehicle = vehiclePriceScale(vehicle, price);
        	Long newPrice = vehicleCalc(vehicle, price);
        	
        	return new Quote(quote.getPickupPostcode(), quote.getDeliveryPostcode(), vehicle, newPrice);
        }catch(NullPointerException e1){
        	return new Quote(quote.getPickupPostcode(), quote.getDeliveryPostcode(), price);
        }
    }
    
    /**
     * This method calculates the right vehicle needed to be used for delivery based on the price limits set.
     * @param vehicle The original vehicle placed in the quote, for recursive calls this is the vehicle that we check whether
     * it's price limit is smaller than the argument price.
     * @param Price The calculated price of delivery based on post codes.
     * @return The actual vehicle that has to be used due to the pricing limits as a String.
     * @throws IllegalArgumentException If the vehicle isn't contained within the static field of vehicle options.
     */
    private String vehiclePriceScale(String vehicle, Long Price) throws IllegalArgumentException{
    	int index = -1;
    	for(int i=0; i<vehicles.length; i++){
    		if(vehicle.equals(vehicles[i])){
    			index  =  i;
    		}
    	}
    	if(index == -1){
    		throw new IllegalArgumentException();//exception thrown if the index is unchanged i.e doesn't match any of the
    											 //vehicle Strings within the static field array of vehicle Strings.
    	}
    	if(Price>limits[index]){
    		return vehiclePriceScale(vehicles[index+1], Price);
    	}else{
    		return vehicle;
    	}
    }

    /**
     * This method calculates the mark up on the delivery price, based on the vehicle that is being used for delivery.
     * @param vehicle The vehicle that is being used to deliver the product.
     * @param price The original price calculated by the post codes, this will be marked up by the method.
     * @return The total marked up price.
     */
	public Long vehicleCalc(String vehicle, Long price){
    	Long result = new Long(0);
    	for(int i=0; i<vehicles.length; i++){
    		if(vehicle.equals(vehicles[i])){
    			double modifier = modifiers[i];
    			result = (long)(price + price*modifier);
    		}
    	}
    	return result;
    }
}
