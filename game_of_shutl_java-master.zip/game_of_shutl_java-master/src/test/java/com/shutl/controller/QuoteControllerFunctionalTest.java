package com.shutl.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shutl.Application;
import com.shutl.model.Quote;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.context.WebApplicationContext;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
public class QuoteControllerFunctionalTest {

    @Autowired private WebApplicationContext webApplicationContext;

    ObjectMapper objectMapper = new ObjectMapper();

    private MockMvc mockMvc;

    @Before
    public void setup() {
        this.mockMvc = webAppContextSetup(this.webApplicationContext).build();
    }

    @Test
    public void testBasicService() throws Exception {
        Quote quoteData = new Quote("SW1A1AA", "EC2A3LT");
        MvcResult result = this.mockMvc.perform(post("/quote")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(quoteData)))
            .andExpect(status().isOk())
            .andReturn();

        Quote quote = objectMapper.readValue(result.getResponse().getContentAsString(), Quote.class);
        assertEquals(quote.getPickupPostcode(), "SW1A1AA");
        assertEquals(quote.getDeliveryPostcode(), "EC2A3LT");
        assertEquals(quote.getPrice(), new Long(253));
    }

    @Test
    public void testVariablePricingByDistance() throws Exception {
        Quote quoteData = new Quote("SW1A1AA", "EC2A3LT");
        MvcResult result = this.mockMvc.perform(post("/quote")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(quoteData)))
            .andExpect(status().isOk())
            .andReturn();

        Quote quote = objectMapper.readValue(result.getResponse().getContentAsString(), Quote.class);
        assertEquals(quote.getPickupPostcode(), "SW1A1AA");
        assertEquals(quote.getDeliveryPostcode(), "EC2A3LT");
        assertEquals(quote.getPrice(), new Long(253));

        quoteData = new Quote("AL15WD", "EC2A3LT");
        result = this.mockMvc.perform(post("/quote")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(quoteData)))
            .andExpect(status().isOk())
            .andReturn();

        quote = objectMapper.readValue(result.getResponse().getContentAsString(), Quote.class);
        assertEquals(quote.getPickupPostcode(), "AL15WD");
        assertEquals(quote.getDeliveryPostcode(), "EC2A3LT");
        assertEquals(quote.getPrice(), new Long(345));
    }
    
    @Test
    public void vehicleQuoteTest1() throws Exception{
    	 Quote quoteData = new Quote("SW1A1AA", "EC2A3LT", "bicycle");
         MvcResult result = this.mockMvc.perform(post("/quote")
                 .contentType("application/json")
                 .content(objectMapper.writeValueAsString(quoteData)))
             .andExpect(status().isOk())
             .andReturn();

         Quote quote = objectMapper.readValue(result.getResponse().getContentAsString(), Quote.class);
         assertEquals(quote.getPickupPostcode(), "SW1A1AA");
         assertEquals(quote.getDeliveryPostcode(), "EC2A3LT");
         assertEquals(quote.getVehicle(), "bicycle");
         assertEquals(quote.getPrice(), new Long(278));
    }
    
    @Test
    public void vehicleQuoteTest2() throws Exception{
    	 Quote quoteData = new Quote("SW1A1AA", "EC2A3LT", "large_van");
         MvcResult result = this.mockMvc.perform(post("/quote")
                 .contentType("application/json")
                 .content(objectMapper.writeValueAsString(quoteData)))
             .andExpect(status().isOk())
             .andReturn();

         Quote quote = objectMapper.readValue(result.getResponse().getContentAsString(), Quote.class);
         assertEquals(quote.getPickupPostcode(), "SW1A1AA");
         assertEquals(quote.getDeliveryPostcode(), "EC2A3LT");
         assertEquals(quote.getVehicle(), "large_van");
         assertEquals(quote.getPrice(), new Long(354));
    }
    
    /**
     * The following tests check whether the application up-scales the vehicle required depending on the price limit of the
     * vehicle that was placed in the quote. In this example bicycle was included in the argument quote, however
     * the price exceeds that of the bicycles limit, where only a large_van can deliver a product with this price.
     * @throws Exception
     */
    @Test
    public void vehicleLimitTest1() throws Exception{
    	 Quote quoteData = new Quote("SW121AA", "EC1A3LT", "bicycle");
         MvcResult result = this.mockMvc.perform(post("/quote")
                 .contentType("application/json")
                 .content(objectMapper.writeValueAsString(quoteData)))
             .andExpect(status().isOk())
             .andReturn();

         Quote quote = objectMapper.readValue(result.getResponse().getContentAsString(), Quote.class);
         assertEquals(quote.getPickupPostcode(), "SW121AA");
         assertEquals(quote.getDeliveryPostcode(), "EC1A3LT");
         assertEquals(quote.getVehicle(), "large_van");
         assertEquals(quote.getPrice(), new Long(2202));
    }
    
    @Test
    public void vehicleLimitTest2() throws Exception{
   	 Quote quoteData = new Quote("SW11A0", "EC1AR0T", "motorbike");
        MvcResult result = this.mockMvc.perform(post("/quote")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(quoteData)))
            .andExpect(status().isOk())
            .andReturn();

        Quote quote = objectMapper.readValue(result.getResponse().getContentAsString(), Quote.class);
        assertEquals(quote.getPickupPostcode(), "SW11A0");
        assertEquals(quote.getDeliveryPostcode(), "EC1AR0T");
        assertEquals(quote.getVehicle(), "small_van");
        assertEquals(quote.getPrice(), new Long(1430));
   }
   
   /**
    * This test checks if the vehicle placed in the request isn't one of the delivery options. If that's the case
    * then we should expect a nested IllegalArgumentException thrown by the vehiclePriceScale method (line 48).
    */
   @Test
   public void badVehicle(){
  	 Quote quoteData = new Quote("SW11A0", "EC1AR0T", "airMail");
  	 
  	 boolean thrown = false;
  	 
  	 try{
       @SuppressWarnings("unused")//only used to try and cause the throw of an IllegalArgumentExcpetion.
       MvcResult result = this.mockMvc.perform(post("/quote")
               .contentType("application/json")
               .content(objectMapper.writeValueAsString(quoteData)))
           .andExpect(status().isOk())
           .andReturn();
       
  	 }catch(Exception e){
  		 if(e.getCause() instanceof IllegalArgumentException){
  			 thrown = true;
  		 }
  	 }
  	 assertTrue(thrown);
   }
}
